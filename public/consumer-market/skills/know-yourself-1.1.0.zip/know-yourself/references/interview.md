# 五问访谈

给愿意从头梳理一遍的人用。每题问完等回答，一题一题来。全部答完再给报告。

题目的设计原则：每题对应一个观察点，答案里自然会出现可供分析的线索，不需要用户额外解释自己的心理。

---

## 第 1 题：意外被打断的那一刻

> 讲一次你原本以为会顺利、结果完全没按计划走的事。那一刻你脑子里第一个念头是什么？接着你做了什么？
>
> 事后你怎么解释那个意外？

**观察点**

- 意外被读成什么：信息，还是威胁，还是运气
- 第一个念头是自我指向（「我完了」）还是任务指向（「下一步怎么办」）
- 有没有出现「努力也没用」这类表述

**依据**：Bandura 2006「People of low efficacy are easily convinced of the futility of effort in the face of difficulties.」；2001「if they construe their failures as presenting surmountable challenges they redouble their efforts, but they drive themselves to despondency if they read their failures as indicants of personal deficiencies」

---

## 第 2 题：和多数人不一样的那次

> 讲一次你违背了别人的建议、家里人的期待或者当时大家都这么做的选择，做了自己想做的事。
>
> 当时那种「没人站在我这边」的感觉，是怎么撑过去的？后来这个决定的结果和你当时的预期一致吗？

**观察点**

- 孤立的感受是被谁接住的
- 有没有个人标准在起作用，还是全靠外部支撑才撑住
- 事后结果与预期不符时，叙述里有没有「我早该知道」这类事后重构

**依据**：Bandura 2001「After they adopt personal standards, people regulate their behavior by self-evaluative outcomes, which may augment or override the influence of external outcomes.」；2001 共同意向「most human pursuits involve other participating agents. Such joint activities require commitment to a shared intention」

---

## 第 3 题：最近一次严重的失败

> 讲一次最近让你觉得自己确实不行的失败，尽量具体。
>
> 如果时间倒流，你觉得当时改哪个变量能改写结果？
>
> 然后再答一遍：如果把同样的处境换一个说法——比如不是「我能力不够」，而是「我在一个缺少某些东西的环境里做这件事」——你的结论有什么不同？

**观察点**

- 归因落在能力、策略，还是环境
- 换框架前后结论是否变化（这是最关键的一问）
- 第二个框架是用户自己找到的，还是从外面拿来的

**依据**：Stanovich & West「the subject might be construing the problem differently and be providing the normatively appropriate answer to a different problem」；「being forced to take more time or to provide a rationale for selections increases adherence to descriptive invariance」；Bandura 2001「The relative magnitude of the personal contribution to the codetermination varies」

---

## 第 4 题：想做的事和实际做的事

> 讲一件你现在想做成、但还没完全做成的事。
>
> 这件事里，哪些部分是你自己在推，哪些部分是交给别人或者等别人推的？为什么这么分？
>
> 如果把「交给别人」的部分拿回来自己做，你猜会发生什么？

**观察点**

- 亲自做 / 借力做 / 一起做的配比
- 借力部分是主动分工（腾出精力）还是被迫交出（回避责任）
- 用户对「拿回来自己做」的预期是能力不足还是负担过重

**依据**：Bandura 2001「Personal control is neither an inherent drive nor universally desired... There is an onerous side to direct personal control that can dull the appetite for it.」；「All too often, they surrender control to intermediaries in activities over which they can command direct influence. They do so to free themselves of the performance demands and onerous responsibilities that personal control entails.」；2006「Everyday functioning requires an agentic blend of these three forms of agency.」

---

## 第 5 题：一次你没做成之后

> 讲一次你知道自己该做、但最后没做的事。
>
> 当时你心里发生了什么？有没有哪个瞬间是「算了，就这样吧」？那个瞬间之前发生了什么？
>
> 这件事里的「应该」，是谁定的？

**观察点**

- 想法与行动之间的断点落在监测、标准还是纠正反应
- 停下来的时刻是被外部反馈打断的，还是自己悄悄关掉的
- 「应该」的来源：自己认同的、外来的、还是模糊的

**依据**：Bandura 2001「These include self-monitoring, performance self-guidance via personal standards, and corrective self-reactions.」；Ryan & Deci 2000 内摄档「behaviors are performed to avoid guilt or anxiety or to attain ego enhancements such as pride」；Stanovich & West 关于 wrong norm「we might be applying the wrong normative model to the problem」

---

## 追问规则

1. 一题一答。答完只回一句收到，不做分析。
2. 用户想跳过某题就跳过，不补问。
3. 用户答得短就顺着短的部分问，不逼长度。
4. 第 3 题的换框架部分，如果用户没反应，换一种说法再问一次，仍无反应就记录为「未测」。
5. 答完 5 题给一次整体报告，中途不插播分析。

## 报告的读法

报告不给人格类型，给的是：

- 处境上，这个环境给你提供了什么、缺了什么
- 机制上，想法和行动之间断在哪一段
- 叙述上，你讲这件事时的用词习惯，以及它可能造成的偏差

三条都可能不准。每条都标了置信度和依据类型（原文主张 / 推测 / 观察）。你自己判断要不要采信。
