# 叙述线索手册

从用户自然语言中读出模式的对照表。每条线索给出：用户会怎么说、它在提示什么、依据来自哪本论文、以及追问方向。

判断时只依据用户实际说过的话。没有说出来的不要推断。

---

## 一、处境层线索

### 1.1 环境类型（Bandura 2001）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「这事不赖我，是他们（公司/家里/环境）弄的」 | 强加环境（imposed） | 改变它需要谁动？只能等外部，还是能换一个位置？ |
| 「当时是自己选的，现在后悔了」 | 选择环境（selected） | 如果重选一次，哪个决定还会重复？ |
| 「这摊子是我自己搭起来的」 | 建造环境（constructed） | 搭起来时你信什么？现在还信吗？ |
| 「不是我想这样，但没办法」 | 约束被体验成必然 | 这句话里的「没办法」，是外部真的封死了，还是没找到别的做法？ |

依据：Bandura 2001「imposed environment, selected environment, and constructed environment. These different environmental structures represent gradations of changeability requiring the exercise of differing scope and focus of personal agency.」

### 1.2 需要受挫（Ryan & Deci 2000）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「做完了也没什么成就感，越来越没信心」 | 胜任受挫 | 反馈是关于结果，还是关于你这个人？ |
| 「我不敢做决定，选什么都得先问他同意」 | 自主受挫 | 「不敢」是不想，还是怕后果？ |
| 「我说了没人接，说什么都没人在乎」 | 关联受挫 | 最近一次有人认真回应你，是什么时候？ |
| 「他们一直在盯我的进度、点评我每一步」 | 控制式环境 | 监控式评价与「说清楚为什么」哪种更多？ |
| 「按流程做完就有绩效」 | 奖励依赖行为 | 除了奖励，这件事本身对你有什么意义？ |
| 「为了家人/关系，我必须放弃我想做的」 | 需要冲突 | 两边真的不能共存吗，还是没找到第三种排法？ |

依据：Ryan & Deci 2000「threats, deadlines, directives, pressured evaluations, and imposed goals diminish intrinsic motivation」；「as when a child is required by parents to give up autonomy in order to feel loved」

### 1.3 结构就在近处（Bandura 2001）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「反正家庭就这样，我也没法选」 | 把结构当成远端 | 这个处境具体怎么占据了你的每一天？哪一段是可以动的？ |
| 「都是这个圈子的问题」 | 集体归因但缺具体接口 | 圈子里哪些人也有同样的卡点？共同的那部分是什么？ |

依据：Bandura 2001「Lacking the money to provide for the subsistence of one's family impinges pervasively on everyday life in a very proximal way. Multicausality involves codetermination of behavior by different sources of influence, not causal dependencies between levels.」

---

## 二、机制层线索

### 2.1 意图在不在（Bandura 2001）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「我决定……然后就……了」 | 有意图，且有行动 | 中间那段「然后」是什么？ |
| 「我不得不……」 | 意图缺位或被压抑 | 「不得不」后面如果换成「我选择」，会怎样？ |
| 「我以为我会做 A，结果做了 B」 | 意图与结果的分离 | 你以为的那一步，和实际做的那一步，哪一步偏了？ |
| 「我本来想放弃的」 | 意图被改写 | 是什么让你改的主意？ |

依据：Bandura 2001「An intention is a representation of a future course of action to be performed. It is not simply an expectation or prediction of future actions but a proactive commitment to bringing them about.」

### 2.2 未来够不够近（Bandura 2001）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「我打算 someday 重新开始」 | 远端目标过远 | 这个目标有具体时间和可检验的产出吗？ |
| 「我知道该做什么，但就是动不了」 | 缺少近端子目标 | 下周的第一小步是什么？小到必定能完成 |
| 「目标太大，不知道从哪下手」 | 目标不具体 | 它具体是什么？做完了什么样？ |

依据：Bandura 2001「Proximal subgoals mobilize self-influences and direct what one does in the here and now. Distal goals alone set the general course of pursuits but are too far removed in time to provide effective incentives and guides for present action.」；「General goals are too indefinite and noncommitting to serve as guides and incentives.」

### 2.3 想法到行动断在哪（Bandura 2001）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「我知道该做什么，但就是没做起来」 | 自我反应性断层 | 监测有发生吗？有个人标准吗？有没有纠正反应？ |
| 「我一直在观察自己，但没改变」 | 只到监测这一段 | 有没有可依据的个人标准？ |
| 「我知道做错了，但懒得改」 | 有标准无纠正 | 纠正动作需要什么条件才能发生？ |

依据：Bandura 2001「These include self-monitoring, performance self-guidance via personal standards, and corrective self-reactions.」；「Monitoring one's pattern of behavior and the cognitive and environmental conditions under which it occurs is the first step toward doing something to affect it.」

### 2.4 风向标反应（Bandura 2001）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「看领导心情」「看对方脸色」 | 行为随外部奖惩摆动 | 除了这次反应，你自己有没有一条相对稳定的标准？ |
| 「给他/她一反馈我就改了」 | 依赖外部奖惩自我导向 | 别人不回应时，你按什么继续？ |

依据：Bandura 2001「people would behave like weather vanes, constantly shifting direction to conform to whatever influence happened to impinge upon them at the moment.」

### 2.5 效能感两极（Bandura 2001/2006）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「努力也没用，试了也没意义」 | 努力无望感 | 上一次有进展是什么时候？哪怕很小 |
| 「我能力不够，做不成」 | 读作个人缺陷 | 如果把它读成一个还没找到方法的挑战呢？ |
| 「这个障碍是可以跨过去的」 | 高效能表述 | 靠哪两项具体能力跨过去？ |

依据：Bandura 2006「People of low efficacy are easily convinced of the futility of effort in the face of difficulties. They quickly give up trying. Those of high efficacy view impediments as surmountable by improvement of self-regulatory skills and perseverant effort.」

### 2.6 行动方式配比（Bandura 2001/2006）

这是本 Skill 取代「强/弱主体」三分类的核心。

**亲自做**（direct / individual agency）

| 用户可能的说法 | 提示 |
|---|---|
| 「我自己决定自己来」 | 亲自推动 |
| 「这事我扛」 | 亲自推动，也可能是负担过重 |
| 「我一个人抗下来了」 | 亲自推动 |

**借力做**（proxy agency）——中性观察，不是批评

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「这事我让专业的来弄」 | 主动分工 | 这是你选的分工，还是你不愿担这个责任？ |
| 「我没这个资源，只能找人」 | 资源受限下的借力 | 你能影响的部分有哪些？ |
| 「反正我不行，交给别人更稳」 | 可能是被迫交出 | 你其实能影响的地方，被你自己划出去了吗？ |

依据：Bandura 2001「Personal control is neither an inherent drive nor universally desired, as is commonly claimed. There is an onerous side to direct personal control that can dull the appetite for it.」；「All too often, they surrender control to intermediaries in activities over which they can command direct influence.」；2006「Everyday functioning requires an agentic blend of these three forms of agency.」

**一起做**（collective agency）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「我们一起搞定了」 | 集体行动 | 你们共享的那份信心，是谁先有的？ |
| 「我想推动团队改变」 | 集体行动 | 团队的共同信念现在是什么状态？ |

依据：Bandura 2001「People's shared belief in their collective power to produce desired results is a key ingredient of collective agency.」

### 2.7 控制感与表现分离（Metcalfe & Greene）

用户最常混淆的两件事。分开记录。

| 用户可能的说法 | 控制感 | 表现 | 追问方向 |
|---|---|---|---|
| 「这都不是我的问题」 | 低 | 不明 | 事情确实不受你影响，还是你不在负责的位置上？ |
| 「我明明很努力了还是不行」 | 高 | 低 | 客观结果是什么？别人怎么评价？ |
| 「我运气好，撞上了」 | 低 | 中 | 这次好结果里，有多少是你做的，有多少是环境给的？ |
| 「这次成了是我运气」 | 低 | 高 | 你有没有为它做过准备？ |

依据：Metcalfe & Greene「People knew, separably from their objective or judged performance, when they were in control and when they were not.」；「They also did not take credit spuriously for the inflated outcomes that occurred by good magic.」

### 2.8 动机档位（Ryan & Deci 2000）

| 用户可能的说法 | 档位 | 追问方向 |
|---|---|---|
| 「我就是提不起劲，懒得动」 | 无动机 | 是不想，还是从没觉得它跟我有关？ |
| 「不做会被考核，做完也没意思」 | 外部调节 | 除了考核，这件事本身对你有什么？ |
| 「我必须做好，不能让人失望」 | 内摄 | 如果做砸了，你觉得自己是什么？ |
| 「我怕搞砸、怕让人觉得我不行」 | 内摄 | 这份怕，是在意这件事，还是在维护形象？ |
| 「我确实需要它，缺了不行」 | 缺失 | 这个需要是真实的，还是被人定义为必需？ |
| 「这件事我认同，虽然累但值」 | 认同 | 认同的是结果，还是这件事本身？ |
| 「它跟我其他看重的东西是一致的」 | 整合 | 它和其他价值冲突吗？ |
| 「我就是喜欢做这个」 | 内在 | 不需要理由也能做的时候有多久？ |

依据：Ryan & Deci 2000 动机连续体原文定义；「behaviors are performed to avoid guilt or anxiety or to attain ego enhancements such as pride」；「Although internally driven, introjected behaviors still have an external perceived locus of causality and are not really experienced as part of the self.」

### 2.9 自我观察（Bandura 2001）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「我注意到我在想……然后就……了」 | 元认知在场 | 停下来看到之后，你做了什么不同？ |
| 「我发现我每次都这样」 | 模式识别能力 | 这个「每次」是哪几次？跨了几个场景？ |
| 「我完全没发现我是这么想的」 | 监控缺口 | 从哪一刻开始没察觉的？ |

依据：Bandura 2001「People are not only agents of action but self-examiners of their own functioning. The metacognitive capability to reflect upon oneself and the adequacy of one's thoughts and actions is another distinctly core human feature of agency.」

---

## 三、叙述层线索

### 3.1 任务构念不同（Stanovich & West）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「这明摆着是 A 问题」 | 已选定构念 | 用另一种描述这个问题，答案会变吗？ |
| 「这不就是常识吗」 | 默认了某个规范 | 这个「应该」是谁定的？ |
| 「我一向想得很清楚」 | 稳定自评 | 换个框架再答一次，还这样吗？ |

依据：Stanovich & West「the subject might be construing the problem differently and be providing the normatively appropriate answer to a different problem」；「frequentist representations of these problems markedly reduce – if not even eliminate – cognitive ability differences」

### 3.2 失误还是偏差（Stanovich & West）

| 用户可能的说法 | 提示 | 追问方向 |
|---|---|---|
| 「我一向都这样判断」 | 可能系统偏差 | 换个情境还成立吗？ |
| 「那次就是走神了」 | 表现失误 | 之后就调整过来了吗？ |

依据：Stanovich & West 引 Evans(1984)「a bias is a source of error which is systematic rather than random」；引 Stein(1996)「a mere mistake」

### 3.3 自我辩解的六种机制（Bandura 2001/2006）

仅在用户主动谈及伤害他人的行为时启用。不主动开启，不做道德评判，只描述结构。

| 用户可能的说法 | 机制 | 追问方向 |
|---|---|---|
| 「情非得已」「也是为了大家好」 | 合理化与神圣化 | 除了这个理由，还有一个吗？ |
| 「说难听点而已」 | 委婉语遮蔽 | 如果对方照字面听了，会有什么感觉？ |
| 「他们更过分」 | 辩解性比较 | 拿谁比的时候，你觉得自己就不需要负责了？ |
| 「是上面让做的，不是我」 | 责任扩散与转移 | 你在里面还有哪部分是你做的？ |
| 「也没造成什么实际损失」 | 结果最小化 | 如果造成了，结论会变吗？ |
| 「他自己也有问题」 | 去人化与责怪受害者 | 这句话让你好受一些了，还是更清楚了？ |

依据：Bandura 2006「sanctification of harmful conduct by moral justification, self-exonerating social comparison, and sanitizing language... obscuring personal agency by diffusion and displacement of responsibility... minimizing, distorting, or even disputing the harm... dehumanizing, demonizing, and blaming the recipients」

---

## 四、追问的边界

追问的形式规则（问几个、哪些给选项、要不要带理由）见 SKILL.md 的「追问规则」。这里只补一条边界：

### 4.1 不追问用户没提的领域

用户没谈工作就不问工作。跨域验证只在用户已经描述过的领域中做。

### 4.2 追问要带理由

提问后加一句「说说为什么」比直接问判断更有效。Stanovich & West：「being forced to take more time or to provide a rationale for selections increases adherence to descriptive invariance」

### 4.3 允许换框架

同一个问题用两种说法各问一次，比较差异。差异本身是数据，不必解释成谁对谁错。
