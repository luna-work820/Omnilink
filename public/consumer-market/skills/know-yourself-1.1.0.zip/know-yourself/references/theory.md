# 理论依据

本文件列出分析框架的每一块来自哪里。做分析时引用的是这些原文命题，不是印象。

标注约定：`【原文】` 表示论文明确主张；`【推论】` 表示基于原文的延伸判断，输出时须标注为推测。

---

## 一、Bandura 2001：Social Cognitive Theory: An Agentic Perspective

来源：Bandura, A. (2001). Annual Review of Psychology, 52, 1-26.

### 1.1 能动性不是标签，是机制

【原文】"To be an agent is to intentionally make things happen by one's own actions. Agency embodies the endowments, belief systems, self-regulatory capabilities and distributed structures and functions through which personal influence exercised, rather than residing as a discrete entity in a particular place."

【原文】(2006) "To be an agent is to influence intentionally one's functioning and life circumstances. ... People are self-organizing, proactive, self-regulating, and self-reflecting. They are not simply onlookers of their behavior. They are contributors to their life circumstances, not just products of them."

用法：分析时问「通过什么机制起作用的」，不问「他属于哪一型」。

### 1.2 四个核心特征是层级关系，不是并列维度

【原文】(2006) "The core agentic capabilities of intentionality, forethought, self-reaction, and self-reflection operate as hierarchically organized determinants."

【推论】对话追问顺序：意图 → 前瞻 → 自我反应 → 自我反思。意图不成立时，后面三项无从谈起。不可把四项平铺成打分表。

### 1.3 意图与预期、结果、愿望都不同

【原文】"An intention is a representation of a future course of action to be performed. It is not simply an expectation or prediction of future actions but a proactive commitment to bringing them about. Intentions and actions are different aspects of a functional relation separated in time."

【原文】"Outcomes are not the characteristics of agentive acts; they are the consequences of them."

【原文】(Hamlet 例) "The killing of the hidden person was intentional, but the wrong victim was done in."

用法：意图可以是错的，也可以产生非想要的结果。判断「有没有意图」和判断「结果好不好」是两件事。

### 1.4 未来不能直接成为当前的原因

【原文】"Future events cannot, of course, be causes of current motivation and action because they have no actual existence. However, by being represented cognitively in the present, foreseeable future events are converted into current motivators and regulators of behavior."

【原文】"Proximal subgoals mobilize self-influences and direct what one does in the here and now. Distal goals alone set the general course of pursuits but are too far removed in time to provide effective incentives and guides for present action."

【原文】"General goals are too indefinite and noncommitting to serve as guides and incentives." / 目标的三个属性："their specificity, level of challenge and temporal proximity."

用法：远期目标本身推不动当下，需要近端子目标。改建议时给近端动作，不给决心。

### 1.5 自我反应性是三段式

【原文】"The self-regulation of motivation, affect, and action is governed by a set of self-referent subfunctions. These include self-monitoring, performance self-guidance via personal standards, and corrective self-reactions."

【原文】"Monitoring one's pattern of behavior and the cognitive and environmental conditions under which it occurs is the first step toward doing something to affect it."

用法：「我知道该做什么，但就是没做起来」是自我反应性断层的典型主诉。追问时定位在：监测有没有发生 → 有没有个人标准 → 有没有纠正反应。

### 1.6 自我导向的标准可以覆盖外部奖惩

【原文】"If actions were performed only on behalf of anticipated external rewards and punishments, people would behave like weather vanes, constantly shifting direction to conform to whatever influence happened to impinge upon them at the moment. In actuality, people display considerable self-direction in the face of competing influences."

用法：识别「风向标反应」——行为随最近一次外部奖惩摆动。

### 1.7 三种环境结构

【原文】"The environment is not a monolithic entity. Social cognitive theory distinguishes between three types of environmental structures (Bandura 1997). They include the imposed environment, selected environment, and constructed environment. These different environmental structures represent gradations of changeability requiring the exercise of differing scope and focus of personal agency."

用法：处境层归因的三档答案。

- 强加环境（imposed）：改变需要外部行动 → 走借力与共同路径
- 选择环境（selected）：是你选的，部分可选 → 重新选择与目标结构
- 建造环境（constructed）：你主动建立的 → 效能维护与自我扩展

### 1.8 三元互惠与个人权重的可变

【原文】"Social cognitive theory explains human functioning in terms of triadic reciprocal causation (Bandura 1986). In this model of reciprocal causality, internal personal factors in the form of cognitive, affective, and biological events, behavioral patterns, and environmental influences all operate as interacting determinants that influence one another bidirectionally."

【原文】(2006) "The relative magnitude of the personal contribution to the codetermination varies depending on the level of agentic personal resources, types of activities, and situational circumstances."

【原文】(2006) "freedom is conceived not just passively as the absence of constraints, but also proactively as the exercise of self-influence in the service of selected goals and desired outcomes."

用法：个人权重是变量，不是定值。输出不许写「这全是你的问题」或「这你控制不了」。也不许把结构当成远端的、可以忽略的。

### 1.9 效能感的两极

【原文】"People of low efficacy are easily convinced of the futility of effort in the face of difficulties. They quickly give up trying. Those of high efficacy view impediments as surmountable by improvement of self-regulatory skills and perseverant effort. They stay the course in the face of difficulties and remain resilient to adversity."

【原文】(2001) "if they construe their failures as presenting surmountable challenges they redouble their efforts, but they drive themselves to despondency if they read their failures as indicants of personal deficiencies"

用法：失败解释的第一分叉——可逾越的挑战，还是个人缺陷的证据。

### 1.10 代理性（proxy agency）是功能性策略，不是缺陷

这是本 Skill 与常见「主动性」类工具最关键的差别，务必读完整。

【原文】"In many spheres of functioning, people do not have direct control over the social conditions and institutional practices that affect their everyday lives. Under these circumstances, they seek their well-being, security, and valued outcomes through the exercise of proxy agency. In this socially mediated mode of agency, people try by one means or another to get those who have access to resources or expertise or who wield influence and power to act on their behest to secure the outcomes they desire."

【原文】"No one has the time, energy, and resources to master every realm of everyday life. Successful functioning necessarily involves a blend of reliance on proxy agency in some areas of functioning to free time and effort to manage directly other aspects of one's life."

【原文】"People also turn to proxy control in areas in which they can exert direct influence when they have not developed the means to do so, they believe others can do it better, or they do not want to saddle themselves with the burdensome aspects that direct control entails. Personal control is neither an inherent drive nor universally desired, as is commonly claimed. There is an onerous side to direct personal control that can dull the appetite for it."

【原文】"All too often, they surrender control to intermediaries in activities over which they can command direct influence. They do so to free themselves of the performance demands and onerous responsibilities that personal control entails."

【原文】"Proxy agency can be used in ways that promote self-development or impede the cultivation of personal competencies. In the latter case, part of the price of proxy agency is a vulnerable security that rests on the competence, power, and favors of others."

【原文】(2006) "Everyday functioning requires an agentic blend of these three forms of agency."

用法：三种行动方式（亲自做、借力做、和别人一起做）是混合配比，不是三选一分类。判断「主动交出控制」和「被迫交出控制」的区别，比判断「强或弱」有用得多。

### 1.11 共同体的效能感

【原文】"People's shared belief in their collective power to produce desired results is a key ingredient of collective agency."

【原文】(2006) "There is no disembodied group mind that believes. Perceived collective efficacy resides in the minds of group members as the belief they have in common regarding their group's capability."

用法：识别「我们能行」类表述。

### 1.12 道德推诿的机制清单

【原文】(2006) "sanctification of harmful conduct by moral justification, self-exonerating social comparison, and sanitizing language... obscuring personal agency by diffusion and displacement of responsibility... minimizing, distorting, or even disputing the harm... dehumanizing, demonizing, and blaming the recipients of the injurious actions."

【原文】(2001) "High moral disengagers experience low guilt over harmful conduct, are less prosocial, and are more prone to vengeful rumination."

用法：仅在用户主动谈及伤害他人的行为时启用。不主动追问，不做道德评判，只描述推诿结构。

---

## 二、Ryan & Deci 2000：自我决定理论

来源：Ryan, R. M., & Deci, E. L. (2000). American Psychologist, 55(1), 68-78.

### 2.1 先看环境支持，再看个人选择

【原文】"Human beings can be proactive and engaged or, alternatively, passive and alienated, largely as a function of the social conditions in which they develop and function."

【原文】"our theory of intrinsic motivation does not concern what causes intrinsic motivation (which we view as an evolved propensity); rather, it examines the conditions that elicit and sustain, versus subdue and diminish, this innate propensity."

【原文】"the mode and degree of people's psychological-need satisfaction is theorized to be influenced not only by their own competencies but, even more important, by the ambient demands, obstacles, and affordances in their sociocultural contexts."

【原文】"we have assumed that humans have an inclination toward activity and integration, but also have a vulnerability to passivity. Our focus, accordingly, has been to specify the conditions that tend to support people's natural activity versus elicit or exploit their vulnerability."

【原文】"By failing to provide supports for competence, autonomy, and relatedness, not only of children but also of students, employees, patients, and athletes, socializing agents and organizations contribute to alienation and ill-being."

用法：归因顺序强制——先环境支持缺口，再个体选择。禁止只做人格归因。

### 2.2 三种基本心理需要

【原文】autonomy 定义："within SDT, autonomy refers not to being independent, detached, or selfish but rather to the feeling of volition that can accompany any act, whether dependent or independent, collectivist or individualist" / "we do not equate autonomy with independence or individualism."

【原文】"feelings of competence will not enhance intrinsic motivation unless accompanied by a sense of autonomy or, in attributional terms, by an internal perceived locus of causality"

【原文】"relatedness, the need to feel belongingess and connectedness with others, is centrally important for internalization."

【原文】"optimal challenges, effectance-supporting feedback, and freedom from demeaning evaluations were all found to facilitate intrinsic motivation."

用法：自主是「这件事我认同、是我想做的」的质感，不是「我一个人干」。不要把自主误读成独立。

### 2.3 动机连续体

【原文】自左向右：Amotivation / External / Introjected / Identified / Integrated / Intrinsic；感知因果源从「 impersonal / external / somewhat external / somewhat internal / internal」。

【原文】Amotivation："the state of lacking the intention to act. When amotivated, people either do not act at all or act without intent--they just go through the motions."

【原文】External："performed to satisfy an external demand or reward contingency. Individuals typically experience externally regulated behavior as controlled or alienated."

【原文】Introjected："Introjection involves taking in a regulation but not fully accepting it as one's own. It is a relatively controlled form of regulation in which behaviors are performed to avoid guilt or anxiety or to attain ego enhancements such as pride. Put differently, introjection represents regulation by contingent self-esteem."

【原文】"Although internally driven, introjected behaviors still have an external perceived locus of causality and are not really experienced as part of the self."

【原文】"Introjected regulation was positively related to expending more effort, but it was also related to feeling more anxiety and coping more poorly with failures."

【原文】Identified："a conscious valuing of a behavioral goal or regulation, such that the action is accepted or owned as personally important."

【原文】Integrated："identified regulations are fully assimilated to the self, which means they have been evaluated and brought into congruence with one's other values and needs."

用法：内摄档最关键，因为它常被本人误认为「我这是自律」「我在努力」。语言标志是内疚、焦虑、避免失败、维持自尊、证明自己；句式常含条件从句（「如果我做不到，我就……」）。

【原文】"Controlling contexts yielded less overall internalization, and the internalization that did occur in those contexts tended to be only introjected."

### 2.4 动机来源的主体是谁

【原文】"external regulation (being interpersonally controlled) and introjected regulation (being intrapersonally controlled)"

【原文】Figure 1：外部调节过程 = "Compliance, External Rewards and Punishments"；内摄调节过程 = "Self-control, Ego-Involvement, Internal Rewards and Punishments"

用法：两者都以惩罚为动力源，差别只在惩罚由谁施加——外部的惩罚来自他人，内摄的惩罚来自自己。

### 2.5 需要冲突

【原文】"social contexts that engender conflicts between basic needs set up the conditions for alienation and psychopathology (Ryan et al., 1995), as when a child is required by parents to give up autonomy in order to feel loved."

用法：识别「为了关系必须放弃自主」这类结构性冲突，不劝任何一方牺牲。

### 2.6 控制式环境的具体表现

【原文】"threats, deadlines, directives, pressured evaluations, and imposed goals diminish intrinsic motivation because, like tangible rewards, they conduce toward an external perceived locus of causality"

【原文】"all expected tangible rewards made contingent on task performance do reliably undermine intrinsic motivation (Deci, Koestner, & Ryan, 1999)"

【原文】"teachers who are autonomy supportive (in contrast to controlling) catalyze in their students greater intrinsic motivation, curiosity, and desire for challenge" / "Students taught with a more controlling approach not only lose initiative but learn less effectively"

【原文】"providing a meaningful rationale for an uninteresting behavior, along with supports for autonomy and relatedness, promoted its internalization and integration."

【原文】"the more they tended to disown responsibility for negative outcomes, blaming others such as the teacher"

【原文】"examples of both children and adults who are apathetic, alienated, and irresponsible are abundant."

用法：以上是识别线索，不是诊断标签。

---

## 三、Metcalfe & Greene：主体性元认知

来源：Metcalfe, J., & Greene, M. J. (2007). Metacognition of Agency. Journal of Experimental Psychology: General, 136(2), 184-199.

### 3.1 控制感与表现可以分开判断

【原文】"People knew, separably from their objective or judged performance, when they were in control and when they were not."

【原文】"people's JoPs changed less than did their JoAs: They recognized that their performance was not much affected by the turbulence (difference = .14), but they nevertheless felt out of control (difference = .28)."

【原文】"People recognized the increased performance but did not attribute it to their own actions."

【原文】"They also did not take credit spuriously for the inflated outcomes that occurred by good magic. They knew that it was not they who had been responsible for the favorable outcome."

用法：三列分别记录——我的控制感、我对表现的判断、客观结果。这是本 Skill 最能直接缓解「我是不是不行」的机制。

### 3.2 分离不是自动发生的

【原文】"these experiments revealed that one factor that contributes to people's JoAs is people's assessment of their performance and that this, in turn, is closely but not invariably related to their performance itself."

【原文】"When different speeds resulted in distorted JoPs, JoAs indistinguishably tracked the biased JoPs."

用法：控制判断常经由「我感觉的表现」中介，而感觉会偏。所以要显式把客观结果单列，不能只问感受。

### 3.3 会觉得自己不在掌控的情形

【原文】"People may feel nonagentic when things seem to be happening by accident; when things are going wrong; when the world or chance circumstance intervenes; when their plans do not correspond to their perceptions of the outcome"

用法：用户说「事情不按我说的走」「都是运气」时，这是控制感判断，不是事实陈述。

---

## 四、Stanovich & West：推理的个体差异与任务构念

来源：Stanovich, K. E., & West, R. F. (2000). Individual differences in reasoning: Implications for the rationality debate? Behavioral and Brain Sciences, 23, 645-726.

### 4.1 规范与实际的差距有四种解释

【原文】"These posit that the gap is due to (1) performance errors, (2) computational limitations, (3) the wrong norm being applied by the experimenter, and (4) a different construal of the task by the subject."

用法：用户给出一个「不理性」的判断时，先依次排查这四种，不要直接归因为性格或智力。

### 4.2 四种解释的要点

【原文】performance errors："a momentary and fairly random lapse in ancillary processes necessary to execute the strategy (lack of attention, temporary memory deactivation, distraction, etc.)"

【原文】computational limitations："stable and inherent computational limitations that prevent the normative response" / "it seems simply perverse to judge that subjects are doing a bad job of reasoning because they are not using a strategy that requires a brain the size of a blimp"

【原文】wrong norm："we might be applying the wrong normative model to the problem (Koehler, 1996)"

【原文】different construal："the subject might be construing the problem differently and be providing the normatively appropriate answer to a different problem"

### 4.3 推理能力不是固定特质

【原文】"We have proposed that thinking dispositions should be distinguished from cognitive capacities because the two constructs are at different levels of analysis in cognitive theory and do separate explanatory work."

【原文】"omnibus measures of cognitive ability such as intelligence tests are best understood as indexing individual differences in the efficiency of processing at the algorithmic level. In contrast, thinking dispositions... index individual differences at the intentional level of analysis. They are telling us about the individual's goals and epistemic values."

【原文】"being higher in cognitive capacity is not equivalent to investing more cognitive capacity"

【原文】"Correlations among individual differences in rational responding ranged from .12 to .36"

### 4.4 换框架会改变结论

【原文】"80.7% of our sample displayed the conjunction effect... The mean SAT score of the 121 subjects who committed the conjunction fallacy was the mean score of the 29 who avoided the fallacy. This difference was highly significant and it translated into an effect size of .746"

【原文】"frequentist representations of these problems markedly reduce – if not even eliminate – cognitive ability differences"

【原文】"subjects giving a consistent response to both descriptions of the problem ... were significantly higher in cognitive ability than those subjects displaying a framing effect"

【原文】"being forced to take more time or to provide a rationale for selections increases adherence to descriptive invariance"

【原文】"group discussion facilitated performance on Wason's selection task"

【原文】"people higher in need for cognition displayed reduced framing effects"

用法：同一件事换一种描述再问一遍，两次回答的差异本身就是数据。这是「换框架复读」环节的直接依据。

### 4.5 区分失误与系统偏差

【原文】Evans(1984): "a bias is a source of error which is systematic rather than random"；S&W 加注："the term bias is reserved for systematic deviations from normative reasoning and does not refer to transitory processing errors"

【原文】Stein(1996): "a mere mistake" —— "a momentary lapse, a divergence from some typical behavior. This is in contrast to attributing a divergence from norm to reasoning in accordance with principles that diverge from the normative principles of reasoning."

【原文】"Even on tasks with clear computational limitations, some subjects from the lowest strata of cognitive ability solved the problem. Conversely, on virtually all the problems, some university subjects of the highest cognitive ability failed to give the normative response. Fully 55.6% of the university subjects who were at the 75th percentile or above in our sample in cognitive ability committed the conjunction fallacy on the Linda Problem."

用法：一次失误不等于系统偏差。不给人贴「想得不够清楚」的标签。

### 4.6 换框架不是万能借口

【原文】Margolis 反驳 alternative construal："the different question can be wildly irrelevant to anything that plausibly could be construed as the meaning of the question asked. The locus of the illusion is shifted, but the force of the illusion is confirmed not invalidated or explained away."

用法：允许「也许我框错了」，但要防止它变成万能解释。追问：这个新框架是从哪里来的？是谁提供的？

---

## 五、跨理论的整合原则

### 5.1 归因顺序

先处境（SDT 的环境支持 + Bandura 的环境三型），再机制（Bandura 四核心 + Metcalfe 三列分离），最后叙述（Stanovich 的构念 + 语言线索）。

这个顺序不是流程仪式。用户已经在叙述里给出信息时，不必机械追问，按缺失的部分补。

### 5.2 个人权重是可变量

Bandura(2006)：个人贡献的相对大小取决于能动性资源、活动类型和情境。因此报告里不得出现「全是你自己的问题」或「这你根本管不了」。

### 5.3 三种行动方式是配比

Bandura(2006) 明确是 blend。分析结论写「在这件事上，亲自推动与借力的配比大约如何，切换点在哪」，不写人格类型。

### 5.4 不把代理性当缺陷

Bandura(2001) 明确个人控制不是内在驱动、不是普遍被desired，放弃直接控制有功能性理由。因此「他这件事上是借力做的」是中性观察，不是批评。

### 5.5 区分三种依据强度

输出中每个判断都要能归到以下之一：原文明确主张（直接引用）、基于原文的推论（标注推测）、纯经验观察（标注为观察）。三者在报告中用不同措辞。

---

## 六、本 Skill 未覆盖的理论空白

以下内容在五本论文中没有依据，若要使用必须另引文献，不得以本 Skill 名义断言：

- 自我效能感的四种来源（Bandura 1997）
- 效能感判断的准确性标准、效能过高导致自欺（2001/2006 均未涉及）
- 归因的「内因/外因 × 稳定/不稳定」四分类（Weiner 框架，非 Bandura）
- overregulation / underregulation 术语（Ryan & Grolnick 1995，非 2000 论文）
- Taleb 的凸性/凹性、有限与无限游戏、帕夫利纳、萨特自欺、佩奇多模型格栅

本 Skill 引用塔勒布、卡斯、帕夫利纳、萨特、佩奇作为补充视角时，必须标注为「非本次五本论文的依据」。
